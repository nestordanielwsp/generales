## Version 1.0
- Initial Commit
- Converted Bootstable library which could only have one event handling method, to class
- Converted comments to english
